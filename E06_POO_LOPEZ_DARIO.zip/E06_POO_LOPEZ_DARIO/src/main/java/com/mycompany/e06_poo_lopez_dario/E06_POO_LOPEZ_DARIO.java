/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.e06_poo_lopez_dario;

/**
 *
 * @author lopez
 */
public class E06_POO_LOPEZ_DARIO {

    public static void main(String[] args) {
      
        Ecuacion_2dogrado ec1 ;
              ec1=new Ecuacion_2dogrado(1,3,2);
             System.out.println( ec1.Imprimir());
        
        
    }
}
